package com.utd.ti.soa.esb_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsbServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
